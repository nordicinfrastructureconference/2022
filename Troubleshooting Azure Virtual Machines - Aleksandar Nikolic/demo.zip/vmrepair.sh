
# start WSL

# az extension add -n vm-repair
az extension list
az vm repair --help
az vm repair create --help
read -s mypassword
az vm repair create -g testvmrepair-rg -n sourcevm --repair-password $mypassword --verbose
# Repair VM admin username: demouser
# Checking if source VM size is available...
# Source VM size 'Standard_B1ms' is available. Using it to create repair VM.
# 
# Creating resource group for repair VM and its resources...
# Source VM uses managed disks. Creating repair VM with managed disks.
# 
# Validating VM template before continuing...
# Copying OS disk of source VM...
# Creating repair VM...
# Attaching copied disk to repair VM...
# 
# Your repair VM 'repair-sourcevm' has been created in the resource group 'repair-sourcevm-20201020072353.846200' with disk 'sourcevm-DiskCopy-20201020072353.846200' attached as data disk. Please use this VM to troubleshoot and repair. Once the repairs are complete use the command 'az vm repair restore -n sourcevm -g trouble-rg --verbose' to restore disk to the source VM. Notethat the copied disk is created within the original resource group 'trouble-rg'.
...
...
#   "repair_resource_group": "repair-sourcevm-20201020072353.846200",
#   "repair_vm_name": "repair-sourcevm",
#   "resource_tag": "repair_source=trouble-rg/sourcevm",
#   "status": "SUCCESS"
# }
# Command ran in 168.403 seconds (init: 0.127, invoke: 168.276)
ssh demouser@REPAIRVM_PUBLICIP
dmesg
dmesg | grep SCSI
sudo mkdir /mnt/troubleshootingdisk
sudo mount /dev/sdc1 /mnt/troubleshootingdisk
cd /mnt/troubleshootingdisk

# fix the issue

exit 

az vm repair list-scripts
az vm repair run -g testvmrepair-rg -n sourcevm --run-id linux-hello-world --run-on-repair --verbose
cat ~/testscript.sh
az vm repair run -g testvmrepair-rg -n sourcevm --custom-script-file ./testscript.sh --run-on-repair --verbose 

# detach the disk from the repair VM and attach it as the OS disk to the source VM
az vm repair restore -n sourcevm -g testvmrepair-rg --verbose