#region Preparation steps

$resourceGroupName = 'trouble-rg'
$location = 'westeurope'
$vnetName = 'demovnet'

New-AzResourceGroup -Name $resourceGroupName -Location $location

$vnet = New-AzVirtualNetwork -Name $vnetName -AddressPrefix 192.168.0.0/16 -ResourceGroupName $resourceGroupName -Location $location
# $vnet = Get-AzVirtualNetwork -Name $vnetName -ResourceGroupName $resourceGroupName

$subnetConfigJb = New-AzVirtualNetworkSubnetConfig -Name demosubnet1 -AddressPrefix 192.168.1.0/24
$vnet.Subnets.Add($subnetConfigJb)
Set-AzVirtualNetwork -VirtualNetwork $vnet

az vm create --image UbuntuLTS --location $location --name linuxvm2 --resource-group $resourceGroupName --size Standard_B1ms --vnet-name $vnetName --subnet demosubnet1 --nsg '""' --generate-ssh-keys --output table
az vm create --image UbuntuLTS --location $location --name linuxvm2 --resource-group $resourceGroupName --size Standard_B1ms --vnet-name $vnetName --subnet demosubnet1 --generate-ssh-keys --output table

# $linuxPublicIP = '52.164.119.220'

$cred = Get-Credential demouser

az vm create --image Win2019Datacenter --location $location --name winvm1 --resource-group $resourceGroupName --size Standard_B1ms --vnet-name $vnetName --subnet demosubnet1  --admin-username $cred.UserName --admin-password $cred.GetNetworkCredential().Password --output table
# 52.164.64.228

#endregion

# Get available virtual machine sizes
Get-AzVMSize -Location westeurope | Select-Object -First 10

# List all compute resource SKUs
Get-AzComputeResourceSku | Where-Object Locations -EQ 'westeurope'

<# Output
virtualMachines         Basic_A0 westeurope           …bscription             MaxResourceVolumeMB 20480
virtualMachines         Basic_A1 westeurope           …bscription             MaxResourceVolumeMB 40960
virtualMachines         Basic_A2 westeurope           …bscription             MaxResourceVolumeMB 61440
virtualMachines         Basic_A3 westeurope           …bscription             MaxResourceVolumeMB …2880
virtualMachines         Basic_A4 westeurope           …bscription             MaxResourceVolumeMB …5760
virtualMachines      Standard_A0 westeurope           …bscription             MaxResourceVolumeMB 20480
virtualMachines      Standard_A1 westeurope           …bscription             MaxResourceVolumeMB 71680
virtualMachines   Standard_A1_v2 westeurope {1, 3, 2}                         MaxResourceVolumeMB 10240
virtualMachines      Standard_A2 westeurope           …bscription             MaxResourceVolumeMB …8240
virtualMachines  Standard_A2m_v2 westeurope {1, 3, 2}                         MaxResourceVolumeMB 20480
virtualMachines   Standard_A2_v2 westeurope {1, 3, 2}                         MaxResourceVolumeMB 20480
#>

#region DEMO: Cannot connect to a Linux VM (linuxvm2)
<#
1. Create a Linux VM, don't open port 22
2. Go to a VM blade
3. Resource Health
4. Troubleshoot Tool link > Common problems > Cannot Connect to VM > Issue: Configuration change...
5. Result: Traffic BLOCKED
6. SOLUTION: Add an NSG rule to open port 22
#>

# How to view the effective Security Rules to determine if the addition 
# or modification of a customer-defined security rule is required.

$VM = Get-AzVM -Name linuxvm2 -ResourceGroupName $resourceGroupName
$VM.NetworkProfile
$NICname = ($VM.NetworkProfile.NetworkInterfaces.Id -split '/')[-1]
Get-AzEffectiveNetworkSecurityGroup -ResourceGroupName $resourceGroupName -NetworkInterfaceName $NICname 

Get-AzEffectiveNetworkSecurityGroup -ResourceGroupName $resourceGroupName -NetworkInterfaceName $NICname | select -ExpandProperty EffectiveSecurityRules | ft
<#
Name                                               Protocol SourcePortRange DestinationPortRange SourceAddressPrefix    Destin                                                                                                                   Prefix 
----                                               -------- --------------- -------------------- -------------------    ------ 
defaultSecurityRules/AllowVnetInBound              All      {0-65535}       {0-65535}            {VirtualNetwork}       {Virt… 
defaultSecurityRules/AllowAzureLoadBalancerInBound All      {0-65535}       {0-65535}            {AzureLoadBalancer}    {0.0.… 
defaultSecurityRules/DenyAllInBound                All      {0-65535}       {0-65535}            {0.0.0.0/0, 0.0.0.0/0} {0.0.… 
defaultSecurityRules/AllowVnetOutBound             All      {0-65535}       {0-65535}            {VirtualNetwork}       {Virt… 
defaultSecurityRules/AllowInternetOutBound         All      {0-65535}       {0-65535}            {0.0.0.0/0, 0.0.0.0/0} {Inte… 
defaultSecurityRules/DenyAllOutBound               All      {0-65535}       {0-65535}            {0.0.0.0/0, 0.0.0.0/0} {0.0.…
#>

az vm show --name linuxvm2 --resource-group $resourceGroupName --query networkProfile.networkInterfaces 
az network nic list-effective-nsg --resource-group $resourceGroupName --name $NICname
az network nic list-effective-nsg --resource-group $resourceGroupName --name $NICname -o table

Get-AzNetworkSecurityGroup -Name linuxvm2NSG -ResourceGroupName $resourceGroupName |
 Add-AzNetworkSecurityRuleConfig -Name "SSH-Rule" -Description "Allow SSH" -Access "Allow" `
 -Protocol "Tcp" -Direction "Inbound" -Priority 100 -SourceAddressPrefix "Internet" `
 -SourcePortRange "*" -DestinationAddressPrefix "*" -DestinationPortRange "22" |
  Set-AzNetworkSecurityGroup

ssh aleksandar@$linuxPublicIP

#endregion


#region DEMO: Test network communication

# To test network communication with Network Watcher, you must first enable a network watcher 
# in the region the VM that you want to test is in, and then use Network Watcher's IP flow verify 
# capability to test communication.

$networkWatcher = Get-AzNetworkWatcher -Name 'NetworkWatcher_westeurope' -ResourceGroupName 'NetworkWatcherRG'
# $networkWatcher = New-AzNetworkWatcher -Name 'NetworkWatcher_westeurope' -ResourceGroupName 'NetworkWatcherRG' -Location 'West Europe'

$vm = Get-AzVM -ResourceGroupName $resourceGroupName -Name winvm1

# Modify my public IP address
Test-AzNetworkWatcherIPFlow `
  -NetworkWatcher $networkWatcher `
  -TargetVirtualMachineId $vM.Id `
  -Direction Inbound `
  -Protocol TCP `
  -LocalIPAddress 192.168.1.5 `
  -LocalPort 3389 `
  -RemoteIPAddress 195.159.210.25 `
  -RemotePort 60000

  Test-AzNetworkWatcherIPFlow `
  -NetworkWatcher $networkWatcher `
  -TargetVirtualMachineId $vM.Id `
  -Direction Inbound `
  -Protocol TCP `
  -LocalIPAddress 192.168.1.5 `
  -LocalPort 80 -RemoteIPAddress 195.159.210.25 -RemotePort 60000

  Test-AzNetworkWatcherIPFlow `
  -NetworkWatcher $networkWatcher `
  -TargetVirtualMachineId $vM.Id `
  -Direction Outbound `
  -Protocol TCP `
  -LocalIPAddress 192.168.1.5 `
  -LocalPort 3000 `
  -RemoteIPAddress 8.8.8.8 `
  -RemotePort 53

# Azure Portal > winvm1 blade > Support + troubleshooting > Connection troubleshoot >
# Specify manually 8.8.8.8:53
# Deployment of a network watcher extension on a winvm1 VM

#endregion


#region DEMO: Wrong user credentials

ssh demouser@$linuxPublicIP
# This uses the VMAccessForLinux extension to reset the credentials of an existing user or 
# create a new user with sudo privileges, and reset the SSH configuration
# Azure portal > Reset password > demouser (new user)

$cred = Get-Credential demouser

az vm user update --resource-group $resourceGroupName --name linuxvm2 `
     --username demouser --password $cred.GetNetworkCredential().password

ssh demouser@$linuxPublicIP

az vm user update --resource-group $resourceGroupName --name linuxvm2 `
    --username demouser --ssh-key-value ~/.ssh/id_rsa.pub

# Using directly VMAccessForLinux extension

az vm extension set --resource-group $resourceGroupName --name linuxvm2 `
    --name VMAccessForLinux --publisher Microsoft.OSTCExtensions --version 1.2 --settings settings.json

# settings.json file can be:

# to reset SSH configuration to default values
{
    "reset_ssh":"True"
}

# to reset SSH credentials for a user
{
    "username":"demouser", "password":"myPassword"
}

# to reset SSH key for a user
{
    "username":"demouser", "ssh_key":"mySSHKey"
}

#endregion


#region DEMO: SERIAL CONSOLE: Misconfigured sshd_config file

ssh demouser@$linuxPublicIP

sudo nano /etc/ssh/sshd_config
# Change "PasswordAuthentication" from "yes" to "no"
sudo systemctl restart sshd.service
# Exit and try to SSH again
# Permission denied (publickey).

# SOLUTION: Azure portal > Reset password > Reset configuration only
az vm user reset-ssh --resource-group $resourceGroupName --name linuxvm2
# Try to SSH again (it works)

# Let's try to fix it with a Serial Console
# misconfigure sshd_config again (notice that file is not the same as before)
# systemctl restart sshd.service
# Open Serial Console, log in, fix sshd_config and restart sshd.service

#endregion


#region DEMO: Serial Console on Windows

# Disable NIC in Server GUI

<#
Serial Console > cmd<enter> > ch -? > ch -sn Cmd0001
Press <esc><tab> for next channel.
Press <esc><tab>0 to return to the SAC channel.
Use any other key to view this channel.
#>

# cmd.exe
netsh interface show interface
netsh interface set interface name=ethernet admin=enabled
netsh interface ip show config

# PowerShell
Get-NetAdapter
Get-NetAdapter -Name "Ethernet" | Enable-NetAdapter

# Misconfigured Windows Firewall
# Disable user mode RDP rules

# Reset RDP configuration > returns OK (but it doesn't work)
Get-NetFirewallRule -Name *remote*desktop*user*mode* | select name,enabled
Get-NetFirewallRule -Name *remote*desktop*user*mode* | Enabled-NetFirewallRule

#endregion


#region DEMO: Redeploy a VM to a new Azure host

# Azure portal > Redeploy

# NOTE: temporary disk data is lost and dynamic IP addresses 
# that are associated with the virtual machine are updated.
az vm redeploy --resource-group $resourceGroupName --name linuxvm2


#endregion


#region DEMO: Action Run Command

Get-AzVMRunCommandDocument -Location westeurope
Get-AzVMRunCommandDocument -Location westeurope | select Id 

Get-AzVMRunCommandDocument -Location westeurope -CommandId EnableWindowsUpdate
az vm run-command show --command-id EnableRemotePS  --location westeurope

Invoke-AzVMRunCommand -ResourceGroupName $resourceGroupName -Name winvm1 -CommandId ipconfig 
az vm run-command invoke --command-id ipconfig --name winvm1 -g $resourceGroupName 

Invoke-AzVMRunCommand -ResourceGroupName $resourceGroupName -Name winvm1 -CommandId 'RunPowerShellScript' -ScriptPath '<pathToScript>' -Parameter @{"arg1" = "var1";"arg2" = "var2"}
az vm run-command invoke -g myResourceGroup -n myVm --command-id RunShellScript --scripts "sudo apt-get update && sudo apt-get install -y nginx"


# Managed Run Command (preview)
Set-AzVMRunCommand -ResourceGroupName trouble-rg -VMName winvm1 -RunCommandName "RunCommandName" -SourceScript "Write-Host Hello World!" -Location westeurope

Get-AzVMRunCommand -ResourceGroupName trouble-rg -VMName winvm1 -Expand instanceView | Format-List *

#endregion

