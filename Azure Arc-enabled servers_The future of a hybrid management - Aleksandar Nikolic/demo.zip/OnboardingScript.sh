 # Download the installation package
wget https://aka.ms/azcmagent -O ~/install_linux_azcmagent.sh

# Install the hybrid agent
bash ~/install_linux_azcmagent.sh

# Run connect command
sudo azcmagent connect --resource-group "hybrid2-rg" --tenant-id "XXXXX-XXXX-XXXX-XXXXX" --location "westeurope" --subscription-id "XXXXX-XXXX-XXXX-XXXXX" --cloud "AzureCloud" --tags "CountryOrRegion=Slovenia" --correlation-id "XXXXX-XXXX-XXXX-XXXXX"

if [ $? = 0 ]; then echo -e "\033[33mTo view your onboarded server(s), navigate to https://portal.azure.com/#blade/HubsExtension/BrowseResource/resourceType/Microsoft.HybridCompute%2Fmachines\033[m"; fi
