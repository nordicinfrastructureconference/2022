
#region Install directly (works on Windows and Linux)

# Run the following commands on a server you want to connect to Azure Arc
Install-Module Az
Install-Module -Name Az.ConnectedMachine

Get-Command -Module Az.ConnectedMachine

# Authenticate to Azure
Connect-AzAccount

# Install the Connected Machine agent on the target machine that can directly communicate to Azure
Connect-AzConnectedMachine -ResourceGroupName <resourcegroupname> -Name <machinename> -Location <region>

<# Steps on an Ubuntu VM
pwsh
Install-Module Az.ConnectedMachine
Connect-AzAccount -DeviceCode
Connect-AzConnectedMachine -ResourceGroupName hybrid2-rg -Location westeurope -Name multipass-ubuntu
#>

#endregion

#region Install and connect by using PowerShell remoting (Windows)

# At the moment, only PowerShell remoting over WSMan is supported
# The team is working on SSH support

# Run the following commands on your admin machine
Install-Module Az
Install-Module -Name Az.ConnectedMachine

# Authenticate to Azure
Connect-AzAccount

# Install the Connected Machine agent on the target machine that can directly communicate to Azure
# The command will automatically use the hostname of a target server
$session = New-PSSession -ComputerName <targetmachinename>
Connect-AzConnectedMachine -PSSession $session -ResourceGroupName <resourcegroupname> -Location <region>

$sessions = New-PSSession -ComputerName <targetmachinename1>, <targetmachinename2>, <targetmachinename3>
Connect-AzConnectedMachine -PSSession $sessions -ResourceGroupName <resourcegroupname> -Location <region>

#endregion

Get-AzConnectedMachineExtension -ResourceGroupName hybrid2-rg -MachineName luka-winvm
Get-AzConnectedMachineExtension -ResourceGroupName hybrid2-rg -MachineName luka-winvm | fl *

foreach ( $ConnectedMachine in (Get-AzConnectedMachine -ResourceGroupName hybrid2-rg).Name ) {
    Get-AzConnectedMachineExtension -ResourceGroupName hybrid2-rg -MachineName $ConnectedMachine |
    Format-Table Name,TypeHandlerVersion, ProvisioningState, @{n='ConnectedMachine';e={$ConnectedMachine}} -GroupBy ConnectedMachine
}

