﻿
#region Interactively onboarding a Linux machine to Azure Arc for Servers

psedit .\OnboardingScript.sh
psedit ./install_linux_azcmagent.sh

#  --resource-name in an optional argument

#endregion

#region Onboarding a Windows machine to Azure Arc for Servers using a service principal

$sp = New-AzADServicePrincipal -DisplayName "Arc-for-servers" -Role "Azure Connected Machine Onboarding"
$sp

$credential = New-Object pscredential -ArgumentList "temp", $sp.Secret
$PlainTextPasssword = $credential.GetNetworkCredential().password

psedit .\OnboardingScript_SPN.ps1

# You will need to manually add your service principal client ID and secret to the onboarding script. Verify that your service principal has the 'Azure Connected Machine Onboarding' role.

 # Add the service principal application ID and secret here
 $servicePrincipalClientId="XXXXX-XXXX-XXXX-XXXXX"
 $servicePrincipalSecret="<ENTER SECRET HERE>"
 
 # Download the installation package
 Invoke-WebRequest -Uri "https://aka.ms/azcmagent-windows" -TimeoutSec 30 -OutFile "$env:TEMP\install_windows_azcmagent.ps1"
 
 # Install the hybrid agent
 & "$env:TEMP\install_windows_azcmagent.ps1"
 if($LASTEXITCODE -ne 0) {
     throw "Failed to install the hybrid agent"
 }
 
 # Run connect command
& "$env:ProgramW6432\AzureConnectedMachineAgent\azcmagent.exe" connect `
  --service-principal-id "$servicePrincipalClientId" `
  --service-principal-secret "$servicePrincipalSecret" `
  --resource-group "hybrid2-vms-rg" `
  --tenant-id "XXXXX-XXXX-XXXX-XXXXX" `
  --location "westeurope" `
  --subscription-id "XXXXX-XXXX-XXXX-XXXXX" `
  --cloud "AzureCloud" `
  --correlation-id "XXXXX-XXXX-XXXX-XXXXX"
 
& "$env:ProgramFiles\AzureConnectedMachineAgent\azcmagent.exe" connect `
    --service-principal-id $sp.ApplicationId.Guid `
    --service-principal-secret $PlainTextPasssword `
    --resource-group "hybrid2-vms-rg" `
    --tenant-id (Get-AzContext).Tenant.Id `
    --location "westeurope" `
    --subscription-id (Get-AzContext).Subscription.Id `
    --cloud "AzureCloud" `
    --correlation-id "XXXXX-XXXX-XXXX-XXXXX" `
    --tags "Datacenter=Datacenter01,City='Novi Sad',StateOrDistrict=Vojvodina,CountryOrRegion=Serbia,environment=demo-arc" `
    --resource-name arc-winvm

#endregion

#region Connect hybrid machines to Azure by using PowerShell

psedit ./'02a-Connect hybrid machines to Azure by using PowerShell.ps1'

#endregion

#region Tagging Azure Arc-enabled Servers resources

# Create a basic taxonomy structure that will allow us to easily query
# and report on where our server resources are hosted

<#
& "$env:ProgramFiles\AzureConnectedMachineAgent\azcmagent.exe" connect `
--service-principal-id $sp.ApplicationId.Guid `
--service-principal-secret $PlainTextPasssword `
--resource-group "hybrid-rg" `
--tenant-id (Get-AzContext).Tenant.Id `
--location "westus2" `
--subscription-id (Get-AzContext).Subscription.Id `
--tags "Datacenter=Datacenter01,City='Novi Sad',StateOrDistrict=Vojvodina,CountryOrRegion=Serbia,environment=demo-arc" `
--resource-name arc-winvm
#>

az tag create --name "Hosting Platform"
az tag add-value --name "Hosting Platform" --value "Azure"
az tag add-value --name "Hosting Platform" --value "AWS"
az tag add-value --name "Hosting Platform" --value "On-premises"

# Apply tags to our Arc server resources
$gcpMachineResourceId = az resource show --resource-group hybrid2-rg --name gcp-linuxvm --resource-type "Microsoft.HybridCompute/machines" --query id --output tsv 
az resource tag --ids $gcpMachineResourceId --tags 'Hosting Platform'=GCP --is-incremental

New-AzTag -Name "Hosting Platform" -Value "Azure"
New-AzTag -Name "Hosting Platform" -Value "AWS"
New-AzTag -Name "Hosting Platform" -Value "GCP"
New-AzTag -Name "Hosting Platform" -Value "On-premises"

Get-AzResource -ResourceType 'Microsoft.HybridCompute/machines' -ResourceGroupName hybrid2-rg |
Update-Aztag -Tag @{Project='NIC-X-Edition'} -Operation Merge


#endregion

#region Using the Azure Resource Graph queries with Azure Arc for Servers resources

# check the Azure Connected Machine Agent (azcmagent) version

# directly on an Azure Arc-enabled machine
azcmagent version

$query1 = @'
resources
| where type == "microsoft.hybridcompute/machines"
| extend agentversion = properties.agentVersion
| extend os = properties.osName
| extend osversion = properties.osVersion
| project name, agentversion, location, resourceGroup, os, osversion
| order by name
'@

Search-AzGraph -Query $query1 | Format-Table -AutoSize

$query2 = @'
resources
| where type == "microsoft.hybridcompute/machines"
| extend agentversion = properties.agentVersion
| summarize count() by tostring(agentversion)
'@

Search-AzGraph -Query $query2

$query4 = @'
resources
| where type == "microsoft.hybridcompute/machines/extensions"
| where id contains 'luka-winvm'
'@

Search-AzGraph -Query $query4 |
 Select-Object -ExpandProperty data |
 Select-Object -ExpandProperty properties |
 Select-Object -ExpandProperty instanceView |
 Select-Object -ExpandProperty status |
 Select-Object -ExpandProperty message

 $query5 = @'
 resources
| where type == "microsoft.hybridcompute/machines/extensions"
| extend
VMName = split(split(id, "/extensions/")[0], "/machines/")[1],
Version = tostring(properties.typeHandlerVersion)
| extend name_version = pack(name, Version)
| summarize Extensions = make_list(name_version) by tostring(VMName)
'@

Search-AzGraph -Query $query5

#endregion

#region Azure Arc for Servers extensions

#region Custom Script extension to install PowerShell 7
Invoke-RestMethod https://aka.ms/install-powershell.ps1 -OutFile install-powershell.ps1
Invoke-RestMethod https://aka.ms/install-powershell.sh -OutFile install-powershell.sh

psedit .\install-powershell.ps1
psedit .\install-powershell.sh

<#
WINDOWS:
install-powershell.ps1
-UseMSI -Quiet -EnablePSRemoting

UBUNTU:
install-powershell.sh
bash install-powershell.sh
#>
#endregion


#endregion