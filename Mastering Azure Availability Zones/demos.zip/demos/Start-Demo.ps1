break # Safety net, this script is not meant to be run all at once

#region 1 - Portal

    # Resource group: 2022-nic-portal-demo-rg
    Start-Process 'https://portal.azure.com'

#endregion

#region 2 - CLI/scripts

    Open-EditorFile -Path '/workspaces/PSDemo/Domain specific/Azure/Availability Zones/Virtual Machines/Scripts/Azure PowerShell.ps1'

    Open-EditorFile -Path '/workspaces/PSDemo/Domain specific/Azure/Availability Zones/Virtual Machines/Scripts/Azure CLI.sh'

    Get-Job

#endregion

#region 3 - Terraform

    <#

    https://www.terraform.io/docs/providers/azurerm/index.html
    We recommend using either a Service Principal or Managed Service Identity when running Terraform non-interactively (such as when running Terraform in a CI server) - and authenticating using the Azure CLI when running Terraform locally.

    Add to Path eller bruk Cloud Shell
    https://docs.microsoft.com/en-us/azure/virtual-machines/linux/terraform-install-configure
    https://www.terraform.io/downloads.html

    Terraform only supports authenticating using the az CLI (and this must be available on your PATH)

    Authenticating via the Azure CLI is only supported when using a User Account. If you're using a Service Principal (for example via az login --service-principal) you should instead authenticate via the Service Principal directly (either using a Client Secret or a Client Certificate).

    https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-windows?view=azure-cli-latest


    #>

    # Authenticate
    az login --use-device-code
    az login --use-device-code --scope https://graph.microsoft.com//.default # Note: --scope needed after Azure CLI 2.37 which is calling MS Graph rather than AAD Graph https://github.com/Azure/azure-cli/issues/22629

    # Configure the context of the subscription you want to operate against:
    az account set -s "b7f543e7-29f0-4e13-8b16-e8e94170be88" #democrayon

    cd "/workspaces/PSDemo/Domain specific/Azure/Availability Zones/Virtual Machines/Terraform"

    Open-EditorFile -Path './main.tf'

    terraform init

    terraform plan

    terraform apply

#endregion

#region 4 - Bicep

    cd "/workspaces/PSDemo/Domain specific/Azure/Availability Zones/Virtual Machines/Bicep"

    Connect-AzAccount -UseDeviceAuthentication
    Set-AzContext democrayon

    # Inspect line 64
    Open-EditorFile -Path ./main.bicep

    # Create a password using PowerShell
    Install-Module -Name RandomPasswordGenerator
    $password = (Get-RandomPassword -PasswordLength 32).PasswordValue

    New-AzResourceGroup -Name 2022-nic-bicep-demo-rg -Location norwayeast
    New-AzResourceGroupDeployment -ResourceGroupName 2022-nic-bicep-demo-rg -TemplateFile ./main.bicep -vmName az-zone-demo5 -location "norwayeast" -OSVersion 2022-datacenter-g2 -vmSize 'Standard_D2s_v5' -zone 2 -adminUsername demoadmin -adminPassword (ConvertTo-SecureString -AsPlainText -Force -String $password)

#endregion

#region 5 - VM gotchas

    <#
     1) Data disks must also be placed into same zone as the VM
     2) In order to move a VM from regional/non-zonal, it must be redeployed
            - Use Azure Site Recovery to replicate the VM and it`s disks into zones
            - Wait for tooling from Microsoft to support this scenario (private preview per June 2022)
    #>

#endregion

#region 6 - Enable replication between Availability Zones for singleton VMs

    New-AzRecoveryServicesVault -Name nic-2022-demo-vault -ResourceGroupName 2022-nic-bicep-demo-rg -Location norwayeast

    Start-Process 'https://docs.microsoft.com/en-us/azure/site-recovery/azure-to-azure-how-to-enable-zone-to-zone-disaster-recovery'

#endregion

#region 7 - Azure subscription mapping

    Open-EditorFile -Path '/workspaces/PSDemo/Domain specific/Azure/Availability Zones/Virtual Machines/Scripts/Test-AzSubscriptionMapping.ps1'

#endregion

#region 7 - Azure Firewall - migration from regional to availability zones

    # Pre-deployed before session due to deployment time (5 - 10 minutes)
    Open-EditorFile -Path '/workspaces/PSDemo/Domain specific/Azure/Availability Zones/Azure Firewall/deploy.ps1'

    # Alternative 1: Export ARM-template, modify and re-deploy
    Open-EditorFile -Path '/workspaces/PSDemo/Domain specific/Azure/Availability Zones/Azure Firewall/Invoke-AzFirewallAvailabilityZoneMigration.ps1'

    # Alternative 2: Get resource ID of firewall instance and generate Bicep template
    $BicepFilePath = "/workspaces/PSDemo/Domain specific/Azure/Availability Zones/Azure Firewall/main.bicep"
    (Get-AzFirewall -Name "crayon-demo-fw" -ResourceGroupName "crayon-demo-firewall-rg").id
    (Get-AzFirewallPolicy -Name "crayon-demo-fwpolicy" -ResourceGroupName "crayon-demo-firewall-rg").id
    (Get-AzFirewallPolicyRuleCollectionGroup -Name crayon_demo_general_rules -ResourceGroupName crayon-demo-firewall-rg -AzureFirewallPolicyName crayon-demo-fwpolicy).Properties.Id

    New-Item -Path $BicepFilePath -Force

    # VS Code Command Palette -> Bicep: Insert resource -> Choose the empty .bicep file we just created -> Paste the resource Id from the above Get-AzFirewall command
    # Repeat for Azure Firewall policy

    # Remove firewall
    Get-AzFirewall -Name "crayon-demo-fw" -ResourceGroupName "crayon-demo-firewall-rg" | Remove-AzFirewall

    # Insert zone-info
    Open-EditorFile -Path $BicepFilePath

    <#
    zones: [
        '1'
        '2'
        '3'
      ]
    #>

    # Re-deploy firewall
    New-AzResourceGroupDeployment -ResourceGroupName crayon-demo-firewall-rg -TemplateFile $BicepFilePath

    # Note: Bug with export of rule collection groups - issue logged here https://github.com/Azure/bicep/issues/6980

#endregion



#region 8 - Cleanup

    Remove-AzResourceGroup -Name 2022-nic-az-cli-demo-rg -Force
    Remove-AzResourceGroup -Name 2022-nic-az-ps-demo-rg -Force
    Remove-AzResourceGroup -Name 2022-nic-portal-demo-rg -Force
    Remove-AzResourceGroup -Name 2022-nic-terraform-demo-rg -Force
    Remove-AzResourceGroup -Name 2022-nic-bicep-demo-rg -Force
    Remove-AzResourceGroup -Name crayon-demo-firewall-rg -Force

#endregion