Connect-AzAccount -UseDeviceAuthentication

Set-AzContext democrayon

New-AzResourceGroup -Name 2022-nic-az-ps-demo-rg -Location 'norwayeast'

Get-Help New-AzVm -Parameter Zone

(Get-RandomPassword -PasswordLength 32).PasswordValue
$Credential = Get-Credential -UserName azureuser

New-AzVm `
    -ResourceGroupName '2022-nic-az-ps-demo-rg' `
    -Name 'az-zone-demo3' `
    -Location 'norwayeast' `
    -Image 'Win2019Datacenter' `
    -Credential $Credential `
    -VirtualNetworkName 'az-zone-vnet' `
    -SubnetName 'vmsubnet' `
    -SecurityGroupName 'az-zone-nsg' `
    -PublicIpAddressName 'az-zone-demo3-pip' `
    -Size Standard_D2s_v3 `
    -Zone 3 `
    -AsJob