#region Register provider if needed

    # Azure PowerShell
    Get-AzProviderFeature -FeatureName AvailabilityZonePeering -ProviderNamespace Microsoft.Resources

    Register-AzProviderFeature -FeatureName AvailabilityZonePeering -ProviderNamespace Microsoft.Resources

    # Alternatively, register on all your subscriptions
    Get-AzSubscription | ForEach-Object {

        Set-AzContext $PSItem.Id

        Register-AzProviderFeature -FeatureName AvailabilityZonePeering -ProviderNamespace Microsoft.Resources

    }

    # Azure CLI
    az feature show -n AvailabilityZonePeering --namespace Microsoft.Resources

    az feature register -n AvailabilityZonePeering --namespace Microsoft.Resources

#endregion

#region Retrieve subscription logical zone mapping via API

    Start-Process 'https://docs.microsoft.com/en-us/rest/api/resources/subscriptions/check-zone-peers'

    Get-AzSubscription

    $azContext = Get-AzContext
    $CurrentSubscriptionId = $azContext.subscription.id

    $TargetSubscriptionId = '477394f0-3bca-4356-bec5-e05fd46ac452'

    $Uri = ('https://management.azure.com/subscriptions/' + $CurrentSubscriptionId + '/providers/Microsoft.Resources/checkZonePeers/?api-version=2020-01-01')

    $body = @{
        'location'        = 'westeurope'#'norwayeast'
        'subscriptionIds' = @(
            "subscriptions/$($TargetSubscriptionId)"
        )
    } | ConvertTo-Json

    $result = (Invoke-AzRestMethod -Uri $Uri -Method POST -Payload $body).Content | ConvertFrom-Json

    $result.availabilityZonePeers

    # Compare all available subscriptions against current context

    $azContext = Get-AzContext
    Get-AzSubscription | ForEach-Object {

        $PSItem

        $CurrentSubscriptionId = $azContext.subscription.id
        $TargetSubscriptionId = $PSItem.Id

        $Uri = ('https://management.azure.com/subscriptions/' + $CurrentSubscriptionId + '/providers/Microsoft.Resources/checkZonePeers/?api-version=2020-01-01')

        $body = @{
            'location'        = 'norwayeast'
            'subscriptionIds' = @(
                "subscriptions/$($TargetSubscriptionId)"
            )
        } | ConvertTo-Json

        $result = (Invoke-AzRestMethod -Uri $Uri -Method POST -Payload $body).Content | ConvertFrom-Json

        $result.availabilityZonePeers
    }

    <# Example output
        availabilityZone peers
        ---------------- -----
        1                {@{subscriptionId=477394f0-3bca-4356-bec5-e05fd46ac452; availabilityZone=2}}
        2                {@{subscriptionId=477394f0-3bca-4356-bec5-e05fd46ac452; availabilityZone=1}}
        3                {@{subscriptionId=477394f0-3bca-4356-bec5-e05fd46ac452; availabilityZone=3}}
    #>

#endregion