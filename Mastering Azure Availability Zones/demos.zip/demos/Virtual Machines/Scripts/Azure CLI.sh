# Authenticate
az login --use-device-code
az login --use-device-code --scope https://graph.microsoft.com//.default  # Note: --scope needed after Azure CLI 2.37 which is calling MS Graph rather than AAD Graph https://github.com/Azure/azure-cli/issues/22629

# Configure the context of the subscription you want to operate against:
az account set -s "b7f543e7-29f0-4e13-8b16-e8e94170be88" #democrayon

# Create resource group to provision VM to
az group create --name 2022-nic-az-cli-demo-rg --location norwayeast

# Search Azure CLI help for information about availability zones
az vm create --help | grep zone

# Alternatively, look in the documentation: https://docs.microsoft.com/en-us/cli/azure/vm?view=azure-cli-latest#az-vm-create

# Create a password using PowerShell
Install-Module -Name RandomPasswordGenerator
$password = (Get-RandomPassword -PasswordLength 32).PasswordValue

az vm create \
    --resource-group 2022-nic-az-cli-demo-rg \
    --name az-zone-demo1 \
    --image Win2019Datacenter \
    --public-ip-sku Standard \
    --admin-username azureuser #--zone 1

az vm create --resource-group 2022-nic-az-cli-demo-rg --name az-zone-demo2 --image UbuntuLTS --public-ip-sku Standard --admin-username azureuser --admin-password $password --zone 1
