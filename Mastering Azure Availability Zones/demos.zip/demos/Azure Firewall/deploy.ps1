cd "/workspaces/PSDemo/Domain specific/Azure/Availability Zones/Azure Firewall"

Connect-AzAccount -UseDeviceAuthentication
Set-AzContext "democrayon"

az login --use-device-code
az account set -s "b7f543e7-29f0-4e13-8b16-e8e94170be88" #democrayon
az login --use-device-code --scope https://graph.microsoft.com//.default # Note: --scope needed after Azure CLI 2.37 which is calling MS Graph rather than AAD Graph https://github.com/Azure/azure-cli/issues/22629

terraform init

terraform plan

terraform apply

terraform destroy

aztfy