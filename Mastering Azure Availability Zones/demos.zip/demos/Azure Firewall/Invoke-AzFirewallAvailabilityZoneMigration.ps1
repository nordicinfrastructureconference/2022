# Credit/more info: Aidan Finn/https://aidanfinn.com/?p=21553

Get-AzFirewall -Name "crayon-demo-fw" -ResourceGroupName "crayon-demo-firewall-rg" | Format-Table name,zones

$AzureFirewallId = (Get-AzFirewall -Name "crayon-demo-fw" -ResourceGroupName "crayon-demo-firewall-rg").id
$BackupFilePath = "/tmp/FirewallBackup.json"

Export-AzResourceGroup -ResourceGroupName "crayon-demo-firewall-rg" -Resource $AzureFirewallId -SkipAllParameterization -Path $BackupFilePath -Verbose

Open-EditorFile -Path $BackupFilePath

<# Add "zones" to exported file
{
    "apiVersion": "2019-04-01",
    "type": "Microsoft.Network/azureFirewalls",
    "name": "[variables('FirewallName')]",
    "location": "[variables('RegionName')]",
    "zones": [
        "1",
        "2",
        "3"
    ],
    "properties": {
        "ipConfigurations": [
            {
#>

Get-AzFirewall -Name "crayon-demo-fw" -ResourceGroupName "crayon-demo-firewall-rg" | Remove-AzFirewall

# Note: Public IP must be zone-redundant, if not the deployment will fail ("Azure Firewall has zone constraint 1, 2, 3, but Public IP referenced by the azure firewall has no zones")

New-AzResourceGroupDeployment -Name "FirewallRestoreJob" -ResourceGroupName "crayon-demo-firewall-rg" -TemplateFile $BackupFilePath

# Verify zone configuration after deployment
Get-AzFirewall -Name "crayon-demo-fw" -ResourceGroupName "crayon-demo-firewall-rg" | Format-Table name,zones